const e=200;function s(n,r){return n>r?`تم جلب ${r} سجل من أصل ${n}. الحد الأقصى 200 سجل — ضيّق الفلاتر لعرض المزيد.`:null}export{e as E,s as e};
